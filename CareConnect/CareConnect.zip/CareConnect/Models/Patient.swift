//
//  AppStateViewModel.swift
//  CareConnect
//
//  Erstellt von Ali Chehab am 17.10.25.
//


import Foundation

/// Patient (Collection: `patients`).
struct Patient: Identifiable, Codable {
    let id: String
    let name: String
    let age: Int
    let city: String
    let meds: [String]
    let avatar: String?
}
