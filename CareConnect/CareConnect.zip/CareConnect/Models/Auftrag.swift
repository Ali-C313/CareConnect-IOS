//
//  AppStateViewModel.swift
//  CareConnect
//
//  Erstellt von Ali Chehab am 17.10.25.
//


import Foundation

/// Auftrag (Collection: `auftraege`). Repräsentiert einen Pflege-Auftrag.
struct Auftrag: Identifiable, Codable {
    let id: String
    let patientName: String
    let patientAge: Int
    let address: String
    let mapThumb: String?
    /// Status: aktuell | offen | erledigt
    let status: String
}
