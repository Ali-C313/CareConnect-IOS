//
//  AppStateViewModel.swift
//  CareConnect
//
//  Erstellt von Ali Chehab am 17.10.25.
//


import Foundation

/// Mitarbeiter (Collection: `employees`).
struct Employee: Identifiable, Codable {
    let id: String
    let name: String
    let age: Int
    let role: String
    let avatar: String?          // Asset-Name oder URL
}
