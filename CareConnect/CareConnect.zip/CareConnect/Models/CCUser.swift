//
//  AppStateViewModel.swift
//  CareConnect
//
//  Erstellt von Ali Chehab am 17.10.25.
//


import Foundation

/// Repräsentiert einen CareConnect-Nutzer in Firestore (Collection: `users`).
/// Klar benannte Felder erleichtern die Pflege in Firebase.
struct CCUser: Identifiable, Codable {
    let uid: String              // Firebase UID (zugleich SwiftUI id)
    var name: String             // Vollständiger Name
    var email: String            // E-Mail-Adresse
    var phone: String?           // Optional: Telefonnummer
    var role: String             // Rolle: Pflegekraft, Leitung, Admin ...
    var status: String           // Arbeitsstatus: verfuegbar | einsatz | pause | krank | frei
    var createdAt: Date          // Konto-Erstellung (UTC)

    var id: String { uid }

    static let empty = CCUser(uid: "", name: "", email: "", phone: nil, role: "Pflegekraft", status: "verfuegbar", createdAt: .init())
}
