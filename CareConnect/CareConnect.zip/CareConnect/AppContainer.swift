//
//  AppContainer.swift
//  CareConnect
//
//  Created by Ali Chehab on 23.10.25.
//

import Foundation
import FirebaseFirestore
import FirebaseStorage
import Combine

final class AppContainer: ObservableObject {
    let orderRepository: OrderProtocol
    let employeeRepository: EmployeeProtocol
    let patientRepository: PatientProtocol
    let pdfRepository: PDFStorageProtocol

    init() {
        self.orderRepository = FirebaseOrderRepository()
        self.employeeRepository = FirebaseEmployeeRepository()
        self.patientRepository = FirebasePatientRepository()
        self.pdfRepository = FirebasePDFStorageRepository()
    }
}
