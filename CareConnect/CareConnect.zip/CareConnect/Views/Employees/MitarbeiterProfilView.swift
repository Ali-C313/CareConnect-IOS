//
//  AppStateViewModel.swift
//  CareConnect
//
//  Erstellt von Ali Chehab am 17.10.25.
//


import SwiftUI

/// Mitarbeiter-Profil (statisches Layout mit Demo-Feldern).
struct MitarbeiterProfilView: View {
    let emp: Employee
    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 16) {
                HStack(spacing: 16) {
                    Image(emp.avatar ?? "p1").resizable().scaledToFill().frame(width: 80, height: 80).clipShape(Circle())
                    VStack(alignment: .leading) {
                        Text(emp.name).font(.title2).bold()
                        Text("\(emp.age) Jahre").foregroundColor(.secondary)
                        Text("Seit 01.05.2024 beschäftigt").foregroundColor(.secondary)
                    }
                }
                Divider()
                Text("Arbeitszeiten").font(.title3).bold().foregroundColor(.red)
                HStack {
                    VStack(alignment: .leading) {
                        Text("Anstellungsart: Vollzeit")
                        Text("Email: name@beispiel.de")
                        Text("Tel.: 0176 998678443")
                    }
                    Spacer()
                    VStack(alignment: .leading) {
                        Text("Mo – Fr: 06:30 – 17:00")
                        Text("Samstag: 08:00 – 17:00")
                    }
                }
                Text("Aktuell Arbeitsplan").font(.title3).bold().foregroundColor(.red)
                Image(CCAssets.hero2).resizable().scaledToFit().cornerRadius(12)
            }
            .padding()
        }
        .navigationTitle("Profil")
    }
}

#Preview { MitarbeiterProfilView(emp: MockData.employees[0]) }
