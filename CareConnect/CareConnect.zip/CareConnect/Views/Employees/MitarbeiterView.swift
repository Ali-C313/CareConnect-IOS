//
//  AppStateViewModel.swift
//  CareConnect
//
//  Erstellt von Ali Chehab am 17.10.25.
//


import SwiftUI
import FirebaseFirestore

/// Mitarbeiterliste. Firestore wird manuell in `Employee` gemappt.
struct MitarbeiterView: View {
    @State private var query = ""
    @State private var items: [Employee] = []
    private let db = FirebaseManager.shared.db

    var body: some View {
        NavigationStack {
            ScrollView {
                searchBar
                LazyVStack(spacing: 12) {
                    ForEach(filtered) { e in
                        NavigationLink { MitarbeiterProfilView(emp: e) } label: { row(for: e) }
                            .buttonStyle(.plain)
                            .padding(.horizontal)
                    }
                }
            }
            .navigationTitle("Mitarbeiter")
        }
        .onAppear { listen() }
    }

    private var filtered: [Employee] {
        items.filter { query.isEmpty ? true : $0.name.lowercased().contains(query.lowercased()) }
    }

    private func listen() {
        db.collection("employees").addSnapshotListener { snap, _ in
            guard let docs = snap?.documents else { return }
            self.items = docs.map { doc in
                let d = doc.data()
                return Employee(
                    id: doc.documentID,
                    name: d["name"] as? String ?? "Unbekannt",
                    age: d["age"] as? Int ?? 0,
                    role: d["role"] as? String ?? "",
                    avatar: d["avatar"] as? String
                )
            }
        }
    }

    private var searchBar: some View {
        HStack { Image(systemName: "magnifyingglass"); TextField("Search", text: $query); Image(systemName: "mic") }
            .padding(10).background(.ultraThinMaterial).cornerRadius(12).padding(.horizontal)
    }

    private func row(for e: Employee) -> some View {
        HStack(spacing: 12) {
            Image(e.avatar ?? "p1").resizable().scaledToFill().frame(width: 52, height: 52).clipShape(Circle())
            VStack(alignment: .leading) {
                Text("\(e.name) \(e.age) Jahre").font(.headline)
                Text(e.role).foregroundColor(.secondary)
                Text("• Im Dienst (Ambulant)").font(.caption).foregroundColor(.green)
            }
            Spacer()
            Image(systemName: "person.2")
        }
        .padding(12).background(.ultraThinMaterial).clipShape(RoundedRectangle(cornerRadius: 18))
    }
}

#Preview { MitarbeiterView() }
