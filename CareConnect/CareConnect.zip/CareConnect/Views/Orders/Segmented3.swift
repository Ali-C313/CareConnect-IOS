//
//  AppStateViewModel.swift
//  CareConnect
//
//  Erstellt von Ali Chehab am 17.10.25.
//


import SwiftUI

/// Kleine 3-teilige Segment-Steuerung (Aktuell/Offen/Erledigt).
struct Segmented3: View {
    let titles: [String]
    @Binding var selected: Int
    var body: some View {
        HStack(spacing: 0) {
            ForEach(titles.indices, id: \.self) { i in
                Button { selected = i } label: {
                    Text(titles[i]).fontWeight(selected == i ? .bold : .regular)
                        .frame(maxWidth: .infinity).padding(.vertical, 10)
                        .background(selected == i ? Color.white.opacity(0.9) : Color.white.opacity(0.2))
                }
            }
        }
        .clipShape(Capsule())
    }
}

#Preview { Segmented3(titles: ["Aktuell","Offen","Erledigt"], selected: .constant(0)) }
