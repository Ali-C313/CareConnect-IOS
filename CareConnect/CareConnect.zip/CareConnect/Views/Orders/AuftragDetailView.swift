//
//  AppStateViewModel.swift
//  CareConnect
//
//  Erstellt von Ali Chehab am 17.10.25.
//


import SwiftUI

/// Auftrag-Detail (Demo). Ergänze Map/Route/Upload nach Bedarf.
struct AuftragDetailView: View {
    let job: Auftrag
    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 16) {
                HStack {
                    VStack { Image("p3").resizable().scaledToFill().frame(width: 72, height: 72).clipShape(Circle()); Text("Sarah Müller") }
                    Image(systemName: "arrow.right")
                    VStack { Image("p1").resizable().scaledToFill().frame(width: 72, height: 72).clipShape(Circle()); Text(job.patientName) }
                }
                Divider()
                Text("Bemerkungen:").foregroundColor(.red).bold()
                Text("… Freitext …").foregroundColor(.secondary)
                Text("Live Standort").foregroundColor(.red).bold()
                Image(CCAssets.mapThumb).resizable().scaledToFill().frame(height: 200).clipShape(RoundedRectangle(cornerRadius: 16))
                VStack(spacing: 10) {
                    pdfTile("Medikamente-\(job.patientName).pdf", large: true)
                    HStack { pdfTile("Bericht-1.pdf"); pdfTile("Bericht-2.pdf"); addTile() }
                }
            }
            .padding()
        }
        .navigationTitle("Aktueller Auftrag")
    }

    private func pdfTile(_ name: String, large: Bool = False) -> some View {
        VStack { Text("PDF").font(.largeTitle).opacity(0.4); Text(name).font(.caption) }
            .frame(maxWidth: .infinity, minHeight: large ? 120 : 80)
            .background(Color.secondary.opacity(0.15))
            .clipShape(RoundedRectangle(cornerRadius: 16))
    }
    private func addTile() -> some View {
        Image(systemName: "plus").font(.title)
            .frame(maxWidth: .infinity, minHeight: 80)
            .background(Color.green)
            .clipShape(RoundedRectangle(cornerRadius: 16))
    }
}

#Preview {
    AuftragDetailView(job: MockData.auftraege[0])
}
