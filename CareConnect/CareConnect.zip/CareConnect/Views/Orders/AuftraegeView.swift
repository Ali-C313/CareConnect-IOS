//
//  AppStateViewModel.swift
//  CareConnect
//
//  Erstellt von Ali Chehab am 17.10.25.
//


import SwiftUI
import FirebaseFirestore

/// Auftragsliste mit Filter-Segment.
struct AuftraegeView: View {
    private let db = FirebaseManager.shared.db
    @State private var query = ""
    @State private var segment = 0
    @State private var items: [Auftrag] = []

    var body: some View {
        NavigationStack {
            VStack(spacing: 10) {
                searchBar
                Segmented3(titles: ["Aktuell","Offen","Erledigt"], selected: $segment)
                    .padding(.horizontal)
                ScrollView {
                    LazyVStack(spacing: 12) {
                        ForEach(filtered) { j in
                            NavigationLink { AuftragDetailView(job: j) } label: { card(for: j) }
                                .buttonStyle(.plain)
                        }
                    }
                    .padding(.horizontal)
                }
            }
            .navigationTitle("Aufträge")
        }
        .onAppear { listen() }
    }

    private var filtered: [Auftrag] {
        let key = ["aktuell","offen","erledigt"][segment]
        return items.filter { $0.status == key && (query.isEmpty ? true : $0.patientName.lowercased().contains(query.lowercased())) }
    }

    private func listen() {
        db.collection("auftraege").addSnapshotListener { snap, _ in
            guard let docs = snap?.documents else { return }
            self.items = docs.map { doc in
                let d = doc.data()
                return Auftrag(
                    id: doc.documentID,
                    patientName: d["patientName"] as? String ?? "Unbekannt",
                    patientAge: d["patientAge"] as? Int ?? 0,
                    address: d["address"] as? String ?? "",
                    mapThumb: d["mapThumb"] as? String,
                    status: d["status"] as? String ?? "offen"
                )
            }
        }
    }

    private var searchBar: some View {
        HStack { Image(systemName: "magnifyingglass"); TextField("Search", text: $query); Image(systemName: "mic") }
            .padding(10).background(.ultraThinMaterial).cornerRadius(12).padding(.horizontal)
    }

    private func card(for j: Auftrag) -> some View {
        VStack(alignment: .leading, spacing: 8) {
            HStack {
                Image(systemName: "person.circle")
                Text("\(j.patientName) \(j.patientAge) Jahre").bold()
                Spacer()
                Image(systemName: "person.2")
            }
            Text(j.address).foregroundColor(.secondary)
            Image(j.mapThumb ?? CCAssets.mapThumb).resizable().scaledToFill()
                .frame(height: 120).clipShape(RoundedRectangle(cornerRadius: 12))
        }
        .padding(12).background(.ultraThinMaterial).clipShape(RoundedRectangle(cornerRadius: 18))
    }
}

#Preview { AuftraegeView() }
