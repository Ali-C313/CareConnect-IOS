//
//  AppStateViewModel.swift
//  CareConnect
//
//  Erstellt von Ali Chehab am 17.10.25.
//


import SwiftUI

/// Hauptnavigation per TabView.
struct MainTabView: View {
    var body: some View {
        TabView {
            HomeView().tabItem { Label("Home", systemImage: "house") }
            PatientenView().tabItem { Label("Patienten", systemImage: "bolt.heart") }
            MitarbeiterView().tabItem { Label("Mitarbeiter", systemImage: "person.3") }
            AuftraegeView().tabItem { Label("Aufträge", systemImage: "envelope") }
        }
    }
}

#Preview { MainTabView() }
