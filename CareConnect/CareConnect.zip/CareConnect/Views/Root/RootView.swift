//
//  AppStateViewModel.swift
//  CareConnect
//
//  Erstellt von Ali Chehab am 17.10.25.
//


import SwiftUI

/// Entscheidet, ob Auth-Flow oder Haupt-App gezeigt wird.
struct RootView: View {
    @EnvironmentObject var app: AppStateViewModel
    var body: some View {
        Group {
            if app.currentUser == nil {
                SplashView()
            } else {
                MainTabView()
            }
        }
    }
}

#Preview {
    RootView().environmentObject(AppStateViewModel())
}
