//
//  AppStateViewModel.swift
//  CareConnect
//
//  Erstellt von Ali Chehab am 17.10.25.
//


import SwiftUI
import FirebaseFirestore

/// Patientenliste. Firestore wird manuell in `Patient` gemappt.
struct PatientenView: View {
    @State private var search = ""
    @State private var items: [Patient] = []
    private let db = FirebaseManager.shared.db

    var body: some View {
        NavigationStack {
            ScrollView {
                searchBar
                LazyVStack(spacing: 16) {
                    ForEach(filtered) { p in
                        NavigationLink { PatientProfilView(p: p) } label: { card(for: p) }
                            .buttonStyle(.plain)
                            .padding(.horizontal)
                    }
                }
                .padding(.top, 6)
            }
            .navigationTitle("Patienten")
        }
        .onAppear { listen() }
    }

    private var filtered: [Patient] {
        items.filter { search.isEmpty ? true : $0.name.lowercased().contains(search.lowercased()) }
    }

    private func listen() {
        db.collection("patients").addSnapshotListener { snap, _ in
            guard let docs = snap?.documents else { return }
            self.items = docs.map { doc in
                let d = doc.data()
                return Patient(
                    id: doc.documentID,
                    name: d["name"] as? String ?? "Unbekannt",
                    age: d["age"] as? Int ?? 0,
                    city: d["city"] as? String ?? "",
                    meds: d["meds"] as? [String] ?? [],
                    avatar: d["avatar"] as? String
                )
            }
        }
    }

    private var searchBar: some View {
        HStack { Image(systemName: "magnifyingglass"); TextField("Search", text: $search); Image(systemName: "mic") }
            .padding(10).background(.ultraThinMaterial).cornerRadius(12).padding(.horizontal)
    }

    private func card(for p: Patient) -> some View {
        VStack(alignment: .leading, spacing: 8) {
            HStack {
                Image(p.avatar ?? "p1").resizable().scaledToFill().frame(width: 56, height: 56).clipShape(Circle())
                VStack(alignment: .leading) {
                    Text(p.name).font(.headline)
                    Text("\(p.age) Jahre\n\(p.city)").font(.subheadline).foregroundColor(.secondary)
                }
                Spacer()
                Image(systemName: "key.fill").foregroundColor(.secondary)
            }
            Text("Medikamente:").foregroundColor(.red).bold()
            ForEach(p.meds, id: \.self) { Text("• \($0)") }
        }
        .padding().background(Color.secondary.opacity(0.15), in: RoundedRectangle(cornerRadius: 22))
    }
}

#Preview { PatientenView() }
