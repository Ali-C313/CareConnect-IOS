//
//  AppStateViewModel.swift
//  CareConnect
//
//  Erstellt von Ali Chehab am 17.10.25.
//


import SwiftUI

/// Notfall-Kontakt als einfache Form. Speichern-Button vorbereitet.
struct NotfallKontaktView: View {
    @State private var name = "Nina Landmann"
    @State private var relation = "Enkelin"
    var body: some View {
        Form {
            Section(header: Text("Notfall Kontakt").foregroundColor(.red)) {
                HStack {
                    Image("p2").resizable().scaledToFill().frame(width: 56, height: 56).clipShape(Circle())
                    VStack(alignment: .leading) { Text(name).bold(); Text(relation).foregroundColor(.secondary) }
                    Spacer()
                    Image(systemName: "phone.fill")
                }
                TextField("Straße, Hausnummer", text: .constant(""))
                TextField("PLZ, Ort", text: .constant(""))
                TextField("Tel.", text: .constant(""))
                TextField("Email", text: .constant(""))
            }
            Button("Speichern") {}
                .frame(maxWidth: .infinity, alignment: .center)
                .foregroundColor(.red)
        }
        .navigationTitle("Notfall")
    }
}

#Preview { NotfallKontaktView() }
