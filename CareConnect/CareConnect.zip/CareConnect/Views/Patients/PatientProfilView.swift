//
//  AppStateViewModel.swift
//  CareConnect
//
//  Erstellt von Ali Chehab am 17.10.25.
//


import SwiftUI

/// Patient-Profil. Ergänze echte Felder/Adresse nach Bedarf.
struct PatientProfilView: View {
    let p: Patient
    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 16) {
                HStack(alignment: .top, spacing: 14) {
                    Image(p.avatar ?? "p1").resizable().scaledToFill().frame(width: 80, height: 80).clipShape(Circle())
                    VStack(alignment: .leading) {
                        Text(p.name).font(.title3).bold()
                        Text("\(p.age) Jahre")
                        Text("Straße , Hausnummer\nPLZ, Ort\nTel.:\nEmail:").foregroundColor(.secondary)
                    }
                    Spacer()
                    Image(systemName: "key.fill")
                    Image(systemName: "doc.on.doc")
                }
                Divider()
                Text("Medikamente:").foregroundColor(.red).bold()
                ForEach(p.meds, id: \.self) { Text("• \($0)") }
                Divider()
                Text("History:").foregroundColor(.red).bold()
                Text("… frei formulierbarer Text …").foregroundColor(.secondary)
                Image(CCAssets.mapThumb).resizable().scaledToFill().frame(height: 180).clipShape(RoundedRectangle(cornerRadius: 16))
            }
            .padding()
        }
        .navigationTitle("Profile")
    }
}

#Preview { PatientProfilView(p: MockData.patients[0]) }
