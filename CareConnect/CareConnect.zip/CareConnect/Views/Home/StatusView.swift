//
//  AppStateViewModel.swift
//  CareConnect
//
//  Erstellt von Ali Chehab am 17.10.25.
//


import SwiftUI

/// Wählt den Arbeitsstatus. onChange schreibt in Firestore.
struct StatusView: View {
    
    var current: String
    var onChange: (String)->Void
    private let options = CCStatus.allCases.map(\.(rawValue))

    var body: some View {
        VStack(alignment: .leading, spacing: 10) {
            Text("Mein Status").font(.headline)
            ForEach(options, id: \.self) { o in
                HStack {
                    Text(o.capitalized)
                    Spacer()
                    if current == o { Image(systemName: "checkmark").foregroundColor(.green) }
                }
                .padding()
                .background(.thinMaterial)
                .cornerRadius(12)
                .onTapGesture { onChange(o) }
            }
        }
    }
}

#Preview { StatusView(current: "verfuegbar", onChange: { _ in }) }
