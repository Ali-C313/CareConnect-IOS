//
//  AppStateViewModel.swift
//  CareConnect
//
//  Erstellt von Ali Chehab am 17.10.25.
//


import SwiftUI

/// Startseite mit Suchleiste, Hero-Karten und Status-Picker.
struct HomeView: View {
    @EnvironmentObject var app: AppStateViewModel
    @State private var search = ""

    var body: some View {
        NavigationStack {
            ZStack {
                Image(CCAssets.background).resizable().scaledToFill().ignoresSafeArea()
                    .overlay(Color.black.opacity(0.08))

                ScrollView {
                    VStack(spacing: 16) {
                        searchBar
                        Image(CCAssets.hero1).resizable().scaledToFill().frame(height: 180).clipped()
                            .cornerRadius(24).padding(.horizontal)
                        Image(CCAssets.hero2).resizable().scaledToFill().frame(height: 180).clipped()
                            .cornerRadius(24).padding(.horizontal)

                        if let u = app.currentUser {
                            StatusView(current: u.status) { app.updateStatus(to: $0) }
                                .padding(.horizontal)
                        }
                    }
                }
            }
            .navigationTitle("Home")
        }
    }

    private var searchBar: some View {
        HStack { Image(systemName: "magnifyingglass"); TextField("Search", text: $search); Image(systemName: "mic") }
            .padding(10).background(.ultraThinMaterial).cornerRadius(12).padding(.horizontal)
    }
}

#Preview { HomeView().environmentObject(AppStateViewModel()) }
