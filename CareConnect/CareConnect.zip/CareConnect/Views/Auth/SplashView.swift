//
//  AppStateViewModel.swift
//  CareConnect
//
//  Erstellt von Ali Chehab am 17.10.25.
//


import SwiftUI

/// Startscreen mit Logo und Knopf in den Auth-Flow.
struct SplashView: View {
    @State private var showAuth = false
    @Environment(\.colorScheme) private var scheme

    var body: some View {
        NavigationStack {
            ZStack {
                Image(CCAssets.background).resizable().scaledToFill().ignoresSafeArea()
                    .overlay(Color.black.opacity(0.15))

                VStack(spacing: 28) {
                    Spacer()
                    Image(scheme == .dark ? CCAssets.appLogoDark : CCAssets.appLogoLight)
                        .resizable().scaledToFit().frame(width: 220)
                        .padding(12)
                        .background(Color(.systemBackground))
                        .clipShape(RoundedRectangle(cornerRadius: 40))
                        .shadow(radius: 6)
                    Spacer()
                    Button("Los Gehts") { showAuth = true }
                        .font(.title3.weight(.semibold))
                        .padding(.horizontal, 40).padding(.vertical, 14)
                        .background(Color.red).foregroundColor(.white).clipShape(Capsule())
                        .navigationDestination(isPresented: $showAuth) { AuthView() }
                    Spacer().frame(height: 40)
                }
                .padding()
            }
        }
    }
}

#Preview { SplashView() }
