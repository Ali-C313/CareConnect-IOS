//
//  AppStateViewModel.swift
//  CareConnect
//
//  Erstellt von Ali Chehab am 17.10.25.
//

import SwiftUI

/// Einfache E-Mail/Passwort Auth. Registrieren & Login teilen sich das Layout.
struct AuthView: View {
    
    @EnvironmentObject var app: AppStateViewModel
    @Environment(\.colorScheme) private var scheme

    @State private var isLogin = true
    @State private var name = ""
    @State private var email = ""
    @State private var password = ""
    @State private var showPwd = false

    var body: some View {
        NavigationStack {
            ZStack {
                Image(CCAssets.background).resizable().scaledToFill().ignoresSafeArea()
                    .overlay(Color.black.opacity(0.15))

                ScrollView {
                    VStack(spacing: 18) {
                        Image(scheme == .dark ? CCAssets.appLogoDark : CCAssets.appLogoLight)
                            .resizable().scaledToFit()
                            .frame(width: 120).padding(8).background(Color(.systemBackground))
                            .clipShape(Circle())
                            .overlay(Circle().stroke(.red, lineWidth: 3))
                            .padding(.top, 24)

                        HStack(spacing: 0) {
                            segment("Registrieren", active: !isLogin) { isLogin = false }
                            segment("Login", active: isLogin) { isLogin = true }
                        }
                        .background(.ultraThinMaterial)
                        .clipShape(RoundedRectangle(cornerRadius: 12))

                        if !isLogin {
                            ccField("Vollständiger Name", text: $name, ct: .name)
                        }
                        ccField("Email", text: $email, ct: .emailAddress, kb: .emailAddress)

                        HStack {
                            Group { showPwd ? TextField("Passwort", text: $password) : SecureField("Passwort", text: $password) }
                            Button { showPwd.toggle() } label { Image(systemName: showPwd ? "eye" : "eye.slash") }
                        }
                        .padding(14).background(.thinMaterial).clipShape(RoundedRectangle(cornerRadius: 12))

                        Button(isLogin ? "Login" : "Registrieren") {
                            if isLogin { app.login(email: email, password: password) }
                            else { app.register(name: name, email: email, password: password) }
                        }
                        .buttonStyle(.borderedProminent).controlSize(.large)

                        if app.isLoading { ProgressView().padding(.top,8) }
                        if let e = app.errorMessage {
                            Text(e).foregroundColor(.red).font(.footnote).multilineTextAlignment(.center)
                        }
                    }
                    .padding()
                }
            }
            .navigationTitle("CareConnect")
        }
    }

    // MARK: UI Hilfsfunktionen
    private func segment(_ title: String, active: Bool, tap: @escaping ()->Void) -> some View {
        Button(action: tap) {
            Text(title).frame(maxWidth: .infinity).padding(.vertical, 12)
                .background(active ? Color.accentColor.opacity(0.2) : .clear)
        }
        .foregroundColor(active ? .primary : .secondary)
    }
    private func ccField(_ placeholder: String, text: Binding<String>, ct: UITextContentType, kb: UIKeyboardType = .default) -> some View {
        TextField(placeholder, text: text)
            .textContentType(ct)
            .keyboardType(kb)
            .autocapitalization(.none)
            .disableAutocorrection(true)
            .padding(14)
            .background(.thinMaterial)
            .clipShape(RoundedRectangle(cornerRadius: 12))
    }
}

#Preview {
    AuthView()
    .environmentObject(AppStateViewModel())
    .preferredColorScheme(.dark)
}
