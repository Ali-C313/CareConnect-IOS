//
//  AppStateViewModel.swift
//  CareConnect
//
//  Erstellt von Ali Chehab am 17.10.25.
//


import SwiftUI
import FirebaseCore

/// App-Entry. Initialisiert Firebase und hängt den globalen AppState an die Environment.
@main
struct CareConnectApp: App {
    @StateObject private var app = AppStateViewModel()

    init() {
        // Firebase initialisieren
        FirebaseApp.configure()
    }

    var body: some Scene {
        WindowGroup {
            RootView()
                .environmentObject(app)
                .preferredColorScheme(nil) // folgt dem System (Dark/Light)
        }
    }
}

#Preview { RootView().environmentObject(AppStateViewModel()) }
