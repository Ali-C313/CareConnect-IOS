//
//  AddressSearchView.swift
//  CareConnect
//
//  Created by Ali Chehab on 01.11.25.
//

import SwiftUI

// MARK: - Reusable SwiftUI-View für Adresssuche
struct AddressSearchView: View {
    @StateObject private var vm = AddressSearchViewModel()
    var title: String = "Adresse"
    var countryCode: String? = "de"
    var onSelect: (String) -> Void

    var body: some View {
        VStack(alignment: .leading, spacing: 8) {
            TextField(title, text: $vm.query)
                .textInputAutocapitalization(.words)
                .disableAutocorrection(true)
                .textFieldStyle(.roundedBorder)
                .onChange(of: vm.query) { _ in vm.onQueryChanged(countryCode: countryCode) }

            if vm.isLoading { ProgressView().scaleEffect(0.9) }

            if !vm.suggestions.isEmpty {
                List(vm.suggestions) { item in
                    Button {
                        vm.select(item)
                        onSelect(item.formatted)
                    } label: {
                        Text(item.formatted)
                            .foregroundStyle(.primary)
                            .lineLimit(2)
                    }
                }
                .listStyle(.plain)
                .frame(maxHeight: 220)
            }

            if let msg = vm.errorMessage {
                Text(msg).foregroundStyle(.red).font(.footnote)
            }
        }
        .animation(.default, value: vm.suggestions)
    }
}


#Preview {
    AddressSearchView(onSelect: { value in
        print("Ausgewählte Adresse:", value)
    })
}
