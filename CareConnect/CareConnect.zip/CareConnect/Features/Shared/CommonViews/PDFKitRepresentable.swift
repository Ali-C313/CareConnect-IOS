import SwiftUI
import PDFKit

/// UIKit bridge for PDFView.
struct PDFKitRepresentable: UIViewRepresentable {
    let document: PDFDocument
    func makeUIView(context: Context) -> PDFView {
        let v = PDFView()
        v.document = document
        v.autoScales = true
        return v
    }
    func updateUIView(_ uiView: PDFView, context: Context) {}
}
