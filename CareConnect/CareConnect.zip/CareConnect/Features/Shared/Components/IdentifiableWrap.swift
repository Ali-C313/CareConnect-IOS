import Foundation

/// Type-erased identifiable wrapper for .sheet(item:).
struct IdentifiableWrap<T>: Identifiable {
    let id = UUID()
    let value: T
}
