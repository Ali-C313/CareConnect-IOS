import SwiftUI

/// Round avatar placeholder used across profile views.
struct PlaceholderAvatarView: View {
    var body: some View {
        Circle()
            .fill(.white.opacity(0.18))
            .frame(width: 72, height: 72)
            .overlay(Image(systemName: "person.fill").foregroundColor(.white))
            .accessibilityLabel("Avatar")
    }
}
