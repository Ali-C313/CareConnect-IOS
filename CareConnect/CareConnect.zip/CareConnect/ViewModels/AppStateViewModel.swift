//
//  AppStateViewModel.swift
//  CareConnect
//
//  Erstellt von Ali Chehab am 17.10.25.
//


import Foundation
import Combine
import FirebaseAuth
import FirebaseFirestore

/// Globaler AppState (MVVM): Authentifizierung, User-Live-Daten & Status-Update.
final class AppStateViewModel: ObservableObject {
    // UI-Status
    @Published var isLoading = false
    @Published var errorMessage: String?
    @Published var currentUser: CCUser?

    // Firestore
    private let db = FirebaseManager.shared.db
    private let auth = FirebaseManager.shared.auth
    private var listeners: [ListenerRegistration] = []

    init() {
        // Beobachte Login/Logout
        auth.addStateDidChangeListener { [weak self] _, user in
            guard let self = self else { return }
            if let user = user {
                self.attachUserDocument(uid: user.uid)
            } else {
                self.detachListeners()
                self.currentUser = nil
            }
        }
    }

    deinit { detachListeners() }

    // MARK: - Auth
    /// Registriert neuen Benutzer und legt entsprechendes Firestore-Dokument an.
    func register(name: String, email: String, password: String) {
        isLoading = true; errorMessage = nil
        auth.createUser(withEmail: email, password: password) { [weak self] res, err in
            guard let self = self else { return }
            if let err = err { self.fail(err); return }
            guard let uid = res?.user.uid else { self.fail("Kein UID"); return }

            let now = Timestamp(date: Date())
            let doc: [String: Any] = [
                "uid": uid,
                "email": email,
                "name": name,
                "phone": NSNull(),            // optionales Feld
                "role": CCRoles.pflegekraft.rawValue,
                "status": CCStatus.verfuegbar.rawValue,
                "createdAt": now
            ]
            self.db.collection("users").document(uid).setData(doc) { e in
                if let e = e { self.fail(e); return }
                self.isLoading = false
            }
        }
    }

    /// Meldet Benutzer an.
    func login(email: String, password: String) {
        isLoading = true; errorMessage = nil
        auth.signIn(withEmail: email, password: password) { [weak self] _, err in
            guard let self = self else { return }
            if let err = err { self.fail(err); return }
            self.isLoading = false
        }
    }

    /// Meldet Benutzer ab.
    func logout() {
        try? auth.signOut()
        detachListeners()
        currentUser = nil
    }

    // MARK: - Status
    /// Aktualisiert den Status des eingeloggten Benutzers.
    func updateStatus(to newStatus: String) {
        guard let uid = currentUser?.uid else { return }
        db.collection("users").document(uid).updateData(["status": newStatus]) { [weak self] err in
            if let err = err { self?.errorMessage = err.localizedDescription }
        }
    }

    // MARK: - Firestore Live-Listener
    private func attachUserDocument(uid: String) {
        detachListeners()
        let l = db.collection("users").document(uid).addSnapshotListener { [weak self] snap, err in
            guard let self = self else { return }
            if let err = err { self.errorMessage = err.localizedDescription; return }
            guard let data = snap?.data() else { return }

            // Manuelles Mapping → unabhängig von FirebaseFirestoreSwift
            let name = (data["name"] as? String).flatMap { $0.isEmpty ? nil : $0 }
            let email = data["email"] as? String ?? ""
            let phone = data["phone"] as? String?
            let role = data["role"] as? String ?? CCRoles.pflegekraft.rawValue
            let status = data["status"] as? String ?? CCStatus.verfuegbar.rawValue
            let createdAt = (data["createdAt"] as? Timestamp)?.dateValue() ?? Date()

            let finalName: String = name ?? (email.split(separator: "@").first.map(String.init) ?? "Nutzer")

            self.currentUser = CCUser(uid: uid, name: finalName, email: email, phone: phone, role: role, status: status, createdAt: createdAt)
        }
        listeners.append(l)
    }

    private func detachListeners() {
        listeners.forEach { $0.remove() }
        listeners.removeAll()
    }

    private func fail(_ err: Error) { fail(err.localizedDescription) }
    private func fail(_ msg: String) { self.errorMessage = msg; self.isLoading = false }
}

#Preview {
    // Vorschau mit Mock-User
    let vm = AppStateViewModel()
    vm.currentUser = MockData.user
    return Text("AppStateViewModel aktiv: \(vm.currentUser?.name ?? "-")").padding()
}
