//
//  OrderProtocol.swift
//  CareConnect
//
//  Created by Ali Chehab on 31.10.25.
//

import Foundation

protocol OrderProtocol {
    func create(_ order: Order) async throws
    func update(id: String, fields: [String: Any]) async throws
    func fetchAll() async throws -> [Order]
}
