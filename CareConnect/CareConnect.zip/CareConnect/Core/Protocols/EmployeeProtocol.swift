//
//  EmployeeProtocol.swift
//  CareConnect
//
//  Created by Ali Chehab on 31.10.25.
//

import Foundation

protocol EmployeeProtocol {
    func fetch(by id: String) async throws -> Employee
    func update(id: String, fields: [String: Any]) async throws
}
