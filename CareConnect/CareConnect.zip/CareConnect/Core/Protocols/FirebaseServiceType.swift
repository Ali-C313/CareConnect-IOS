//
//  FirebaseServiceType.swift
//  CareConnect
//
//  Created by Ali Chehab on 31.10.25.
//

import Foundation
import FirebaseFirestore

protocol FirebaseServiceType {
    func fetchEmployees() async throws -> [Employee]
    func fetchPatients()  async throws -> [Patient]
    func fetchOrders()    async throws -> [Order]
    func fetchPatient(by id: String) async throws -> Patient?
    func updateOrder(id: String, fields: [String: Any]) async throws
    func updateEmployee(id: String, fields: [String: Any]) async throws
    func updatePatient(id: String, fields: [String: Any]) async throws
    func listen<T: Decodable>(to collection: String, as type: T.Type,
                              onChange: @escaping (Result<[T], Error>) -> Void) -> ListenerRegistration
}
