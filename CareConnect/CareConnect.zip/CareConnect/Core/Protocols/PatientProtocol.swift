//
//  PatientProtocol.swift
//  CareConnect
//
//  Created by Ali Chehab on 31.10.25.
//

import Foundation

protocol PatientProtocol {
    func fetch(by id: String) async throws -> Patient
    func fetchAll() async throws -> [Patient]
}
