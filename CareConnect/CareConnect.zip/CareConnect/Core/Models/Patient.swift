//
//  Patient.swift
//  CareConnect
//
//  Created by Ali Chehab on 11.10.25.
//

import Foundation
import FirebaseFirestore

struct Medication: Identifiable, Codable, Hashable {
    var id: String = UUID().uuidString
    var name: String
}

struct EmergencyContact: Identifiable, Codable, Hashable {
    @DocumentID var id: String? // Firestore optional ID
    var name: String
    var relation: String?
    var phone: String?
    var email: String?
    var address: String?
    var age: Int?
}

struct Patient: Identifiable, Codable, Hashable {
    @DocumentID var id: String?
    var uid: String? // Firebase User UID for matching Orders
    var firstName: String?
    var lastName: String?
    var address: String?
    var phone: String?
    var email: String?
    var allergies: String?
    var medicalHistory: String?
    var age: Int?
    var birthDate: Timestamp?
    var notes: String?
    var profileImageURL: String?   // neu

    // UI-Zusatz
    var medications: [Medication]? = []
    var history: [String]? = []
    var emergencyContact: EmergencyContact? = nil

    // Computed
    var name: String {
        let first = (firstName ?? "").trimmingCharacters(in: .whitespaces)
        let last  = (lastName  ?? "").trimmingCharacters(in: .whitespaces)
        let full  = [first, last].filter { !$0.isEmpty }.joined(separator: " ")
        if !full.isEmpty { return full }
        return email ?? "Unbekannt"
    }

    var city: String?
}
