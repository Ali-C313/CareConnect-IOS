//
//  AppStateViewModel.swift
//  CareConnect
//
//  Erstellt von Ali Chehab am 17.10.25.
//


import SwiftUI

/// Praktischer View-Modifier zum bedingten Anwenden.
extension View {
    @ViewBuilder
    func `if`(_ condition: Bool, transform: (Self) -> some View) -> some View {
        if condition { transform(self) } else { self }
    }
}
