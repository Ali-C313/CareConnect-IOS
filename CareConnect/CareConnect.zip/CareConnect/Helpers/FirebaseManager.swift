//
//  AppStateViewModel.swift
//  CareConnect
//
//  Erstellt von Ali Chehab am 17.10.25.
//


import Foundation
import FirebaseCore
import FirebaseAuth
import FirebaseFirestore

/// Zentraler Zugriffspunkt für Firebase. So vermeiden wir doppelte Initialisierungen/Imports.
final class FirebaseManager {
    static let shared = FirebaseManager()
    let auth: Auth
    let db: Firestore

    private init() {
        self.auth = Auth.auth()
        self.db = Firestore.firestore()
    }
}
