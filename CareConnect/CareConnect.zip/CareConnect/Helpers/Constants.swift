//
//  AppStateViewModel.swift
//  CareConnect
//
//  Erstellt von Ali Chehab am 17.10.25.
//


import SwiftUI

/// Zentrale Konstanten: Asset-Namen, Rollen, Statusoptionen.
enum CCAssets {
    static let appLogoLight = "AppLogoLight"
    static let appLogoDark  = "AppLogoDark"
    static let background   = "Background"
    static let hero1        = "Hero1"
    static let hero2        = "Hero2"
    static let mapThumb     = "MapThumb"
}

enum CCRoles: String, CaseIterable {
    case pflegekraft = "Pflegekraft"
    case leitung     = "Leitung"
    case admin       = "Admin"
}

enum CCStatus: String, CaseIterable {
    case verfuegbar, einsatz, pause, krank, frei
}
