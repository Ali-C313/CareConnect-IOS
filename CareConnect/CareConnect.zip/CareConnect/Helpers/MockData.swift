//
//  AppStateViewModel.swift
//  CareConnect
//
//  Erstellt von Ali Chehab am 17.10.25.
//


import Foundation

/// Beispiel-Daten für Previews/Offline-Design.
enum MockData {
    static let user = CCUser(uid: "demo-uid", name: "Ali Chehab", email: "ali@example.com", phone: "0176 123456", role: "Pflegekraft", status: "verfuegbar", createdAt: .init())

    static let employees: [Employee] = [
        .init(id: "e1", name: "Alex Meyer", age: 35, role: "Pflegekraft", avatar: "p1"),
        .init(id: "e2", name: "Nina Schulz", age: 29, role: "Leitung", avatar: "p2")
    ]

    static let patients: [Patient] = [
        .init(id: "p1", name: "Berta Landmann", age: 88, city: "Berlin", meds: ["Med A", "Med B"], avatar: "p1"),
        .init(id: "p2", name: "Heinz Krüger", age: 76, city: "Hamburg", meds: ["Med X"], avatar: "p2")
    ]

    static let auftraege: [Auftrag] = [
        .init(id: "a1", patientName: "Berta Landmann", patientAge: 88, address: "Beispielstraße 1, Berlin", mapThumb: nil, status: "aktuell"),
        .init(id: "a2", patientName: "Heinz Krüger", patientAge: 76, address: "Musterweg 2, Hamburg", mapThumb: nil, status: "offen")
    ]
}
